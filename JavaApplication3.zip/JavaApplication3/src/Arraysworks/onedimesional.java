/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arraysworks;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Mudassir Malik
 */
public class onedimesional {

    public void array(){
        
    int marks[][] ;
    
    marks = new int[3][3];
    
    marks [0][0] = 122 ;
    marks [0][1] = 111 ;
    marks [0][2] = 156;
    
    marks [1][0] = 100;
    marks [1][1] = 200;
    marks [1][2] = 300;
    
    marks [2][0] = 50;
    marks [2][1] = 75;
    marks [2][2] = 95;
    
        for (int i = 0; i < 3; i++) {

            for (int j = 0; j < 3; j++) {
                
            System.out.println("Roll number " + marks[i][j]);    
            }
           System.out.println(); 
        }
    
    }
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        Scanner sca = new Scanner(System.in);
//        int a ;
//        a = sca.nextInt();
//        System.out.println(a);
        
        onedimesional obj = new onedimesional();
        obj.array();
    }
    
}
