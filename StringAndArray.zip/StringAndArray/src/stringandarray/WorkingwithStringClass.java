/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringandarray;

/**
 *
 * @author Student
 */
public class WorkingwithStringClass {
    
     StringBuilder str =  new StringBuilder("Hello"); // Initialize a String variable
     Integer strLength = 5; // Use the Integer wrapper class
     
      /**
 * Displays strings using various String class methods
 *
 * @return void
 */
 public void displayStrings(){
 // using various String class methods
 System.out.println("String length is:"+ str.length());
 System.out.println("Character at index 1 is:"+ str.charAt(1));
 System.out.println("Concatenated string is:"+ str.append("World"));
 System.out.println("String comparison is:"+ "Hello".equals("Hello"));
 System.out.println("Index of o is:"+ str.indexOf("o"));
 System.out.println("Last index of l is:"+ str.lastIndexOf("d"));
 System.out.println("Replaced string is:"+ str.toString().replace("World" , "ali"));
 System.out.println("Substring is:"+ str.substring(2, 5));
 System.out.println("Integer to String is:"+ strLength.toString()) ;
 String str1=" Hello ";
 System.out.println("Untrimmed string is:"+ str1);
 System.out.println("Trimmed string is:"+ str1.trim());
 }
    public static void main(String[] args) {
        WorkingwithStringClass obj = new WorkingwithStringClass();
        obj.displayStrings();
    }
}
